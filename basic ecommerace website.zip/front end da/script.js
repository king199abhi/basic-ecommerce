document.getElementById('joinButton').addEventListener('click', function() {
    const email = document.getElementById('emailInput').value;
    const messageDiv = document.getElementById('message');
    if (email === "") {
        messageDiv.textContent = "Please enter your email address.";
        messageDiv.className = "message error";
        messageDiv.style.display = "block"; 
        return;
    }
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        messageDiv.textContent = "Please enter a valid email address.";
        messageDiv.className = "message error"; 
        messageDiv.style.display = "block"; 
        return;
    }
    messageDiv.textContent = "Thank you for joining! A confirmation email will be sent to " + email;
    messageDiv.className = "message"; 
    messageDiv.style.display = "block"; 

    document.getElementById('emailInput').value = '';
});
